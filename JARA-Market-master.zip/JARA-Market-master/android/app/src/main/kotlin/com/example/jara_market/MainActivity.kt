package com.example.jara_market

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
